#ifndef _PM_DEVICE_H_
#define  _PM_DEVICE_H_

#if TOS_CFG_PWR_MGR_EN > 0u 

extern k_pm_device_t pm_device_uart;

#endif

#endif

