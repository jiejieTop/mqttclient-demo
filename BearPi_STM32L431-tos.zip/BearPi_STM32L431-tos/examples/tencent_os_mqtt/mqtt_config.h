#ifndef _TOS_MQTT_CONFIG_H_
#define  _TOS_MQTT_CONFIG_H_

#define MQTT_SERVER_IP          "111.230.189.156"
#define MQTT_SERVER_PORT        "1883"
#define MQTT_PRODUCT_ID         "RUAP1R610V"
#define MQTT_DEV_NAME           "supowang"
#define MQTT_CLIENT_ID          "RUAP1R610Vsupowang"
#define MQTT_USR_NAME           "RUAP1R610Vsupowang;12010126;LQUY4;1620700055"
#define MQTT_PASSWORD           "98398cb32f7cb9d73da51fea84bf400c7f17a3303548624731d76fa8db3b43ff;hmacsha256"
#define MQTT_SUBSCRIBE_TOPIC    "RUAP1R610V/supowang/data"
#define MQTT_PUBLISH_TOPIC      "RUAP1R610V/supowang/data"

#endif

